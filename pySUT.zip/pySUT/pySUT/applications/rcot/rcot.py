import numpy as np

#%% Rectangular choice of technology: aggregating interchangeable products rows


def calc_Z_r(L,Z_0):
    """
    This function provides a rectangular endogenous transactions matrix 'Z_r', where rows of interchangeable products are aggregated.
    """







