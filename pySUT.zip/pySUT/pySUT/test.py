import pandas as pd

supply_database = 'supply/naio_10_cp15.tsv'
supply = pd.read_csv(supply_database, sep='\t',index_col=0)  

indices_names = ["unit","stk_flow","induse","prod_na","geo"]

ind = supply.index


