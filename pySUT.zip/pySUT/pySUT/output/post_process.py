import numpy as np



def dict_delta_1_0(ML_iot_0,ML_iot_1,x_0,x_1,E_0):
    
    Z_0 = ML_iot_0['Z']
    Z_1 = ML_iot_1['Z']

    W_0 = ML_iot_0['W']
    W_1 = ML_iot_1['W']

    M_0 = ML_iot_0['M']
    M_1 = ML_iot_1['M']

    Y_0 = ML_iot_0['Y']
    Y_1 = ML_iot_1['Y']

    R_0 = ML_iot_0['R']
    R_1 = ML_iot_1['R']

    E_1 = ML_iot_1['E']
    
    delta_Z = np.zeros((Z_0.shape[0], Z_0.shape[1], Z_0.shape[2]))
    delta_W = np.zeros((W_0.shape[0], W_0.shape[1], W_0.shape[2]))
    delta_M = np.zeros((M_0.shape[0], M_0.shape[1], M_0.shape[2]))
    delta_Y = np.zeros((Y_0.shape[0], Y_0.shape[1], Y_0.shape[2]))
    delta_x = np.zeros((x_0.shape[0], x_0.shape[1], x_0.shape[2]))
    
    for l in range(Z_0.shape[0]):
        delta_Z[l] = Z_1[l] - Z_0[l]
        delta_W[l] = W_1[l] - W_0[l]
        delta_M[l] = M_1[l] - M_0[l]
        delta_Y[l] = Y_1[l] - Y_0[l]
        delta_x[l] = x_1[l] - x_0[l]
    
    delta_R = R_1 - R_0
    delta_E = E_1 - E_0
   
    delta_1_0 = {
                 'delta_Z': delta_Z,
                 'delta_W': delta_W,
                 'delta_M': delta_M,
                 'delta_Y': delta_Y,
                 'delta_x': delta_x,
                 'delta_R': delta_R,   
                 'delta_E': delta_E,
                }
    
    return(delta_1_0)






